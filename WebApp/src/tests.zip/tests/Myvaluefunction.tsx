

export default function Myvaluefunction(){

    const myA = (aa=19):number=> aa+1; 
    const myB = (bb=29):number=> bb+1; 
}
