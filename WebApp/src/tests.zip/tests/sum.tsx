
export default function Sum (){

    function add(a: number, b: number): number {
        return a + b;
        
    };

    
}