test('faker', () => {
    expect(true).toBe(true);
});

// import React from 'react';
// import { render, screen } from '@testing-library/react';
// import App from '../App';
// import exp from 'constants';

// test('renders learn react link', async () => {
//   render(<App />);
//   const length = await screen.debug.length;
//   console.log(length);
//   const htmlElement : HTMLElement  = await screen.getByText('Test application to compare Weather forecast')
//   expect(htmlElement).toBeDefined();

//   const htmlElement1 : HTMLElement  = await screen.getByText('Dan')
//   expect(htmlElement1).toBeDefined();
  
// });

 